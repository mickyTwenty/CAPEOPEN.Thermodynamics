﻿// ReSharper disable All

namespace VCRC.Tests;

public sealed class ComparisonFixture
{
    public double Tolerance { get; } = 1e-3;
}
