﻿namespace VCRC;

internal interface IHeatReleaserNode : IMainHeatExchangerNode, IEntropyAnalysisNode;
