﻿namespace VCRC;

internal interface IMainHeatExchangerNode
{
    IRefrigerant Outlet { get; }
}
