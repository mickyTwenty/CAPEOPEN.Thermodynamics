﻿namespace VCRC;

/// <summary>
///     Heat releaser (condenser or gas cooler).
/// </summary>
public interface IHeatReleaser : IMainHeatExchanger;
