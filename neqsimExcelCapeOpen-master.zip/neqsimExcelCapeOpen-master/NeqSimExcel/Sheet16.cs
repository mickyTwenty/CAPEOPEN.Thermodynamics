﻿using System;
using Office = Microsoft.Office.Core;

namespace NeqSimExcel
{
    public partial class Sheet16
    {
        private void Sheet16_Startup(object sender, EventArgs e)
        {
        }

        private void Sheet16_Shutdown(object sender, EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        ///     Required method for Designer support - do not modify
        ///     the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            Startup += Sheet16_Startup;
            Shutdown += Sheet16_Shutdown;
        }

        #endregion
    }
}